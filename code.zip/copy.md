### Short Skill Description

Want to know more about bananas? Add BananaGeek to your Echo to learn about them!

### Full Skill Description

Bananas are amazing and fun fruits. If you don't know about them, then you should today! The world is your oyster/banana when you are banana-fluent. Let's get started by adding BananaGeek to your Echo!

### Example Phrases

- Alexa, tell me a fact from BananaGeek.
- Alexa, let banana facts tell me a BananaGeek.
- Alexa, tell me something from BananaGeek.

### Categories

- Games, Trivia & Accessories

### Sub Category

- Knowledge & Trivia

### Keywords

- banana, facts, trivia, random


### Testing Instructions

No accounts required. Try out the sample commands!
